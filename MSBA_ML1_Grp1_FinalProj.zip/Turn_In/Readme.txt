Final Project for MSBA - ML 1 Mini 3

Steve Barnard
Ray(Rui) Li
Tarak Talpade